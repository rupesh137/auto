package com.journaldev.hibernate.model;

public class ICFormFieldsBean implements Comparable<ICFormFieldsBean>, Cloneable{
	
	private String icFormFieldsId;
	private String icMerchantMasterId;
	private String fieldLabel;
	private String fieldType;
	private String fieldValue;
	private String forDisplay;
	private String forIdentification;
	private String filler1;	
	private String filler2;	
	private String filler3;
	private String userValue;
	private String customerId;
	private String paramUrlValue;
	private String orderOfField;
	private String uploadId;
	private String toPGAddnInfo;
	private String fieldMapping;
	private String isMandatory;
	private String ICAdhocSectionId;
	private String paymentId;
	private String forAuthentication;
	private String createdOn;
	private String createdBy;
	private String modifiedOn;
	private String modifiedBy;
	private String status;
	public ICFormFieldsBean clone() throws CloneNotSupportedException{
		ICFormFieldsBean clonedObj = (ICFormFieldsBean) super.clone(); 
		return clonedObj;
	}
	public String getParamUrlValue() {
		return paramUrlValue;
	}
	public void setParamUrlValue(String paramUrlValue) {
		this.paramUrlValue = paramUrlValue;
	}
	public String getIcFormFieldsId() {
		return icFormFieldsId;
	}
	public void setIcFormFieldsId(String icFormFieldsId) {
		this.icFormFieldsId = icFormFieldsId;
	}
	public String getIcMerchantMasterId() {
		return icMerchantMasterId;
	}
	public void setIcMerchantMasterId(String icMerchantMasterId) {
		this.icMerchantMasterId = icMerchantMasterId;
	}
	public String getFieldLabel() {
		return fieldLabel;
	}
	public void setFieldLabel(String fieldLabel) {
		this.fieldLabel = fieldLabel;
	}
	public String getFieldType() {
		return fieldType;
	}
	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}
	public String getFieldValue() {
		return fieldValue;
	}
	public void setFieldValue(String fieldValue) {
		this.fieldValue = fieldValue;
	}
	public String getForDisplay() {
		return forDisplay;
	}
	public void setForDisplay(String forDisplay) {
		this.forDisplay = forDisplay;
	}
	public String getForIdentification() {
		return forIdentification;
	}
	public void setForIdentification(String forIdentification) {
		this.forIdentification = forIdentification;
	}
	public String getFiller1() {
		return filler1;
	}
	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}
	public String getFiller2() {
		return filler2;
	}
	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}
	public String getFiller3() {
		return filler3;
	}
	public void setFiller3(String filler3) {
		this.filler3 = filler3;
	}
	public String getUserValue() {
		return userValue;
	}
	public void setUserValue(String userValue) {
		this.userValue = userValue;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	
	public String getOrderOfField() {
		return orderOfField;
	}
	public void setOrderOfField(String orderOfField) {
		this.orderOfField = orderOfField;
	}
	
	public String getUploadId() {
		return uploadId;
	}
	public void setUploadId(String uploadId) {
		this.uploadId = uploadId;
	}
	
	public String getToPGAddnInfo() {
		return toPGAddnInfo;
	}
	public void setToPGAddnInfo(String toPGAddnInfo) {
		this.toPGAddnInfo = toPGAddnInfo;
	}
	public String getIsMandatory() {
		return isMandatory;
	}
	public void setIsMandatory(String isMandatory) {
		this.isMandatory = isMandatory;
	}
	
	public int compareTo(ICFormFieldsBean ffBean) {
		if(ffBean==null){
			return 0;
		}
		int newOrder = 0, oldOrder=0;
	
			try{
				newOrder = Integer.parseInt(ffBean.getOrderOfField());
			}catch(NumberFormatException e ){			
			}
			try{
				oldOrder = Integer.parseInt(this.getOrderOfField());
			}catch(NumberFormatException e ){			
			}
		
		return oldOrder- newOrder;
	}
	public String getFieldMapping() {
		return fieldMapping;
	}
	public void setFieldMapping(String fieldMapping) {
		this.fieldMapping = fieldMapping;
	}
	public String getICAdhocSectionId() {
		return ICAdhocSectionId;
	}
	public void setICAdhocSectionId(String iCAdhocSectionId) {
		ICAdhocSectionId = iCAdhocSectionId;
	}
	public String getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}
	public String getForAuthentication() {
		return forAuthentication;
	}
	public void setForAuthentication(String forAuthentication) {
		this.forAuthentication = forAuthentication;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
}
