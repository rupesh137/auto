package com.journaldev.hibernate.model;

public class ICFormFieldsValueBean {
	private String icFormFieldsId;
	private String icFormFieldsValueId;
	private String userValue;
	private String customerId;
	private String createdOn;
	private String createdBy;
	private String modifiedOn;
	private String modifiedBy;
	private String status;
	
	public String getIcFormFieldsId() {
		return icFormFieldsId;
	}
	public void setIcFormFieldsId(String icFormFieldsId) {
		this.icFormFieldsId = icFormFieldsId;
	}
	public String getUserValue() {
		return userValue;
	}
	public void setUserValue(String userValue) {
		this.userValue = userValue;
	}
	public String getCustomerId() {
		return customerId;
	}
	public String getIcFormFieldsValueId() {
		return icFormFieldsValueId;
	}
	public void setIcFormFieldsValueId(String icFormFieldsValueId) {
		this.icFormFieldsValueId = icFormFieldsValueId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
